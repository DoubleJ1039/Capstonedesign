package com.example.pas.repositories;

public class Repository {

}
